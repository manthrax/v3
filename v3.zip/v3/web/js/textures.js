
require(["util/gl-util",function(glUtil){
    return{
        textures:{},
        get: function(texName){
        //	textures[texName]={loadHandle:glUtil.loadTexture("
        }
    }
}]
);